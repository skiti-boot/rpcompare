from __future__ import print_function
import json, os, urllib2
from django.utils.text import slugify
from compare.models import Category, Store, Product, Offer, PriceHistory

def post(url, payload, headers=None):
    req = urllib2.Request(url, data=json.dumps(payload))
    req.add_header("Content-Type", "application/json")
    for k,v in (headers or {}).items():
        req.add_header(k,v)
    return json.loads(urllib2.urlopen(req, timeout=30).read())

def token():
    cid=os.environ.get("AMAZON_CREATOR_CLIENT_ID")
    secret=os.environ.get("AMAZON_CREATOR_CLIENT_SECRET")
    if not cid or not secret:
        raise RuntimeError("Set AMAZON_CREATOR_CLIENT_ID and AMAZON_CREATOR_CLIENT_SECRET.")
    result=post(os.environ.get("AMAZON_CREATOR_TOKEN_URL","https://api.amazon.com/auth/o2/token"), {
        "grant_type":"client_credentials","client_id":cid,"client_secret":secret,
        "scope":"creatorsapi::default"
    })
    return result["access_token"]

def import_search(keywords):
    marketplace=os.environ.get("AMAZON_MARKETPLACE","www.amazon.com")
    partner=os.environ.get("AMAZON_PARTNER_TAG")
    if not partner:
        raise RuntimeError("Set AMAZON_PARTNER_TAG.")
    data=post("https://creatorsapi.amazon/catalog/v1/searchItems", {
        "keywords":keywords,"marketplace":marketplace,"partnerTag":partner,
        "resources":["images.primary.large","itemInfo.title","offersV2.listings"]
    }, {"Authorization":"Bearer "+token(),"x-marketplace":marketplace})
    store,_=Store.objects.get_or_create(name="Amazon",defaults={"website":"https://www.amazon.com"})
    cat,_=Category.objects.get_or_create(slug="electronics",defaults={"name":"Electronics"})
    count=0
    for item in data.get("searchResult",{}).get("items",[]):
        asin=item.get("asin")
        title=item.get("itemInfo",{}).get("title",{}).get("displayValue")
        if not asin or not title: continue
        product,_=Product.objects.update_or_create(
            slug=(slugify(title)[:50]+"-"+asin.lower()),
            defaults={"name":title,"category":cat,"description":title,
                      "image_url":item.get("images",{}).get("primary",{}).get("large",{}).get("url","")})
        listings=item.get("offersV2",{}).get("listings",[])
        if not listings: continue
        money=listings[0].get("price",{}).get("money",{})
        price=money.get("amount")
        url=item.get("detailPageURL") or item.get("detailPageUrl")
        if price is None or not url: continue
        offer,_=Offer.objects.update_or_create(product=product,store=store,defaults={
            "price":price,"currency":money.get("currencyCode","USD"),
            "product_url":url,"affiliate_url":url,"in_stock":True})
        PriceHistory.objects.create(offer=offer,price=offer.price)
        count+=1
    return count
