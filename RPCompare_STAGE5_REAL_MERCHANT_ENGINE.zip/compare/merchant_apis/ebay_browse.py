from __future__ import print_function
import base64, json, os, urllib, urllib2
from django.utils.text import slugify
from compare.models import Category, Store, Product, Offer, PriceHistory

def get(url, headers):
    req=urllib2.Request(url)
    for k,v in headers.items(): req.add_header(k,v)
    return json.loads(urllib2.urlopen(req,timeout=30).read())

def token():
    cid=os.environ.get("EBAY_CLIENT_ID")
    secret=os.environ.get("EBAY_CLIENT_SECRET")
    if not cid or not secret:
        raise RuntimeError("Set EBAY_CLIENT_ID and EBAY_CLIENT_SECRET.")
    raw=base64.b64encode((cid+":"+secret).encode("utf-8")).decode("ascii")
    body=urllib.urlencode({"grant_type":"client_credentials","scope":"https://api.ebay.com/oauth/api_scope"})
    req=urllib2.Request("https://api.ebay.com/identity/v1/oauth2/token",data=body)
    req.add_header("Content-Type","application/x-www-form-urlencoded")
    req.add_header("Authorization","Basic "+raw)
    return json.loads(urllib2.urlopen(req,timeout=30).read())["access_token"]

def import_search(keywords):
    params=urllib.urlencode({"q":keywords,"limit":"100"})
    headers={"Authorization":"Bearer "+token(),
             "X-EBAY-C-MARKETPLACE-ID":os.environ.get("EBAY_MARKETPLACE_ID","EBAY_US"),
             "Accept":"application/json"}
    campaign=os.environ.get("EBAY_CAMPAIGN_ID")
    if campaign:
        headers["X-EBAY-C-ENDUSERCTX"]="affiliateCampaignId=%s,affiliateReferenceId=%s" % (
            campaign,os.environ.get("EBAY_REFERENCE_ID","rpcompare"))
    data=get("https://api.ebay.com/buy/browse/v1/item_summary/search?"+params,headers)
    store,_=Store.objects.get_or_create(name="eBay",defaults={"website":"https://www.ebay.com"})
    cat,_=Category.objects.get_or_create(slug="electronics",defaults={"name":"Electronics"})
    count=0
    for item in data.get("itemSummaries",[]):
        title=item.get("title"); iid=item.get("itemId")
        price=item.get("price",{}).get("value")
        if not title or not iid or price is None: continue
        url=item.get("itemAffiliateWebUrl") or item.get("itemWebUrl")
        if not url: continue
        product,_=Product.objects.update_or_create(
            slug=slugify(title)[:50]+"-"+slugify(iid)[-20:],
            defaults={"name":title,"category":cat,"description":title,
                      "image_url":item.get("image",{}).get("imageUrl","")})
        offer,_=Offer.objects.update_or_create(product=product,store=store,defaults={
            "price":price,"currency":item.get("price",{}).get("currency","USD"),
            "product_url":item.get("itemWebUrl") or url,
            "affiliate_url":url,"in_stock":True})
        PriceHistory.objects.create(offer=offer,price=offer.price)
        count+=1
    return count
