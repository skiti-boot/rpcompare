from django.shortcuts import render, get_object_or_404
from django.db.models import Q
from .models import Product, Category

def home(request):
    products = Product.objects.all().order_by("-updated_at")[:8]
    categories = Category.objects.all().order_by("name")
    return render(request, "home.html", {"products": products, "categories": categories})

def search(request):
    q = request.GET.get("q", "").strip()
    products = Product.objects.filter(
        Q(name__icontains=q) | Q(description__icontains=q)
    ).distinct() if q else Product.objects.none()
    return render(request, "search.html", {"products": products, "q": q})

def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug)
    offers = product.offers.filter(in_stock=True).select_related("store").order_by("price")
    return render(request, "product_detail.html", {"product": product, "offers": offers})

def category(request, slug):
    category_obj = get_object_or_404(Category, slug=slug)
    products = category_obj.products.all().order_by("name")
    return render(request, "category.html", {"category": category_obj, "products": products})

def about(request):
    return render(request, "simple.html", {"title": "About RPcompare", "text": "RPcompare was created by Roshan K Parmar to make product price comparison easier."})

def contact(request):
    return render(request, "simple.html", {"title": "Contact", "text": "For questions, partnerships, or corrections, contact the RPcompare team."})

def privacy(request):
    return render(request, "simple.html", {"title": "Privacy Policy", "text": "This page will contain RPcompare's privacy policy before public launch."})

def terms(request):
    return render(request, "simple.html", {"title": "Terms of Use", "text": "This page will contain RPcompare's terms of use before public launch."})
