from django.conf.urls import url
from . import views

urlpatterns = [
    url(r"^$", views.home, name="home"),
    url(r"^search/$", views.search, name="search"),
    url(r"^category/(?P<slug>[-\w]+)/$", views.category, name="category"),
    url(r"^product/(?P<slug>[-\w]+)/$", views.product_detail, name="product_detail"),
    url(r"^stores/$", views.stores, name="stores"),
    url(r"^store/(?P<store_id>\d+)/$", views.store_detail, name="store_detail"),
    url(r"^go/(?P<offer_id>\d+)/$", views.go_to_store, name="go_to_store"),
    url(r"^about/$", views.about, name="about"),
    url(r"^contact/$", views.contact, name="contact"),
    url(r"^privacy/$", views.privacy, name="privacy"),
    url(r"^terms/$", views.terms, name="terms"),
]
