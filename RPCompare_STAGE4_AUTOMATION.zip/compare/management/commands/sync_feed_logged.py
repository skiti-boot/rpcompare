from datetime import datetime

from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone

from compare.feed_importer import import_feed
from compare.models import SyncLog


class Command(BaseCommand):
    help = "Run an RPCompare merchant feed synchronization and record the result."

    def add_arguments(self, parser):
        parser.add_argument("--file", required=True)

    def handle(self, *args, **options):
        filename = options["file"]
        log = SyncLog.objects.create(source=filename, status="running")

        try:
            stats = import_feed(filename)
            log.products_created = stats.get("products_created", 0)
            log.products_updated = stats.get("products_updated", 0)
            log.offers_created = stats.get("offers_created", 0)
            log.offers_updated = stats.get("offers_updated", 0)
            log.prices_recorded = stats.get("prices_recorded", 0)
            log.skipped = stats.get("skipped", 0)
            log.status = "success"
            log.message = "Feed synchronization completed successfully."
            log.finished_at = timezone.now()
            log.save()

            self.stdout.write(self.style.SUCCESS(
                "Stage 4 sync complete | products +%s/%s | offers +%s/%s | prices %s | skipped %s"
                % (
                    log.products_created, log.products_updated,
                    log.offers_created, log.offers_updated,
                    log.prices_recorded, log.skipped,
                )
            ))
        except Exception as exc:
            log.status = "failed"
            log.message = str(exc)
            log.finished_at = timezone.now()
            log.save()
            raise CommandError("Feed synchronization failed: %s" % exc)
